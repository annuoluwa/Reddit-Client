import React from "react";
import styles from './footer.module.css'

function Footer() {
    return(
        <h4 className={styles.footer}>Reddit Client v1.0 • Built with ❤️ by leezab3th</h4>
    )
}

export default Footer;