const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const morgan = require('morgan')

console.log('APP.JS STARTED');

// Log uncaught exceptions and unhandled promise rejections
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason && reason.stack ? reason.stack : reason);
});

const fetch = require('node-fetch');

app.use(cors());

app.use(morgan('dev'))

app.use(express.static(path.join(__dirname, '../reddit-client/build')));


// Search Reddit posts by query
app.get('/search', async (req, res) => {
  console.log('SEARCH ROUTE HIT', req.query);
  const { q, limit, after } = req.query;
  if (!q || typeof q !== 'string' || q.trim() === '') {
    return res.status(400).json({ error: 'Missing or invalid search query' });
  }

  let limitValue = parseInt(limit, 10);
  if (isNaN(limitValue) || limitValue < 1) limitValue = 5;
  if (limitValue > 100) limitValue = 100;

  let queryString = `?q=${encodeURIComponent(q)}&limit=${limitValue}&sort=relevance&type=link`;
  if (after) {
    queryString += `&after=${after}`;
  }

  const url = `https://www.reddit.com/search.json${queryString}`;
  try {
    console.log('About to fetch:', url);
    const response = await fetch(url, {
      headers: { 'User-Agent': 'reddit-proxy-bot/1.0' }
    });
    console.log('Fetch complete');
    if (!response.ok) {
      console.error('Fetch response not ok:', response.status, response.statusText);
      return res.status(500).json({ error: 'Failed to fetch from Reddit search API' });
    }
    const data = await response.json();
    console.log('JSON parsed');
    res.json(data);
  } catch (error) {
    console.error('Error fetching from Reddit search API:', error && error.stack ? error.stack : error);
    res.status(500).json({ error: 'Failed to fetch search results' });
  }
});


app.get('/reddit/:subreddit', async (req, res) => {
  const { subreddit } = req.params;
  const { after, limit } = req.query;

// Default limit to 5 if not provided
  let limitValue = parseInt(limit, 10);
   if (isNaN(limitValue) || limitValue < 1) limitValue = 5;
  if (limitValue > 100) limitValue = 100; // Reddit max

  
  console.log('Received limit:', limit, 'Parsed limitValue:', limitValue);



  //  query string for Reddit API
  let queryString = `?limit=${limitValue}`;
  if (after) {
    queryString += `&after=${after}`;
  }

  // Full Reddit API URL
  const url = `https://www.reddit.com/r/${subreddit}.json${queryString}`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error('Error fetching from Reddit:', error);
    res.status(500).json({ error: 'Failed to fetch data' });
  }
});

app.get('/comments/:subreddit/:postId', async (req, res) => {
  const { subreddit, postId } = req.params;
  const url = `https://www.reddit.com/r/${subreddit}/comments/${postId}.json`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      return res.status(404).json({ error: 'Post not found on Reddit' });
    }
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error('Error fetching comments from Reddit:', error);
    res.status(500).json({ error: 'Failed to fetch comments' });
  }
});

app.get('/', (req, res) => {
  res.send('serving all route');
});


module.exports = app;
console.log('APP.JS STARTED');console.log('APP.JS STARTED');